#include "function.h"

char Zigbee_Readstr[128] = {0};
char Zigbee_Sendstr[128] = {0};

ThresHod Auto_Threshod;//��ֵ
void AUTO_Threshod_Init(void)   //��ʼ��ֵ����
{
    
    Auto_Threshod.Temperature_Min = 10;
    Auto_Threshod.Temperature_Max = 30;
    Auto_Threshod.Humidity_Min = 20;
    Auto_Threshod.Humidity_Max = 65;
    Auto_Threshod.Intensity_Min = 20;
    Auto_Threshod.Intensity_Max = 80;
    Auto_Threshod.Smoke_Min = 20;
    Auto_Threshod.Smoke_Max = 1000;
    Auto_Threshod.Air = 0;
    Auto_Threshod.Curtain = 0;
    Auto_Threshod.Window = 0;
}
void LED_Install(void)
{
        gd_eval_led_on(LED1);
        gd_eval_led_off(LED2);
        delay_1ms(1000);
        gd_eval_led_on(LED2);
        gd_eval_led_off(LED1);
        delay_1ms(1000);
}

uint8_t AUTO_or_Contrul_Flag = 0;   //1----����    0----�Զ�
void ZigBee_Send_Recevice(void)
{
    //�ж�----�Ƿ�������
    if(ZigBee_Recvice_Flag == 1)
    {
        ZigBee_Send_Flag = 0;             //zigbee���ͱ�־λ  �ö�ʱ��2s����һ��
        ZigBee_Recvice_Flag = 0;          //zigbee���ձ�־λ  �ö�ʱ��2s���һ��
        if(AUTO_or_Contrul_Flag == 1)     //����ģʽ------��Ҫ�����Դӻ����п��Ƶ�ʱ��
        {
            scanf("%s",USART0_Tx_buffer);  //��������������-------OFF-A:1-C:1-W:1\r\n
            
            sprintf(UART3_Tx_DMA_buffer,"%s\r\n",USART0_Tx_buffer);
            UART3_DMA_Send(UART3_Tx_DMA_buffer);
            printf("USART0_Tx_buffer:%s\r\n",USART0_Tx_buffer);
            printf("�������ӽڵ㷢�͵���Ϣ:%s\r\n",UART3_Tx_DMA_buffer);
            
            printf("�ӽڵ�Ӧ�ö�ȡ���������͵���Ϣ��%s\r\n",UART3_Tx_DMA_buffer);
        }
        else if(AUTO_or_Contrul_Flag == 0)
        {
            //���͸�ʽ
            
            printf("��ȡ���ӽڵ㷢�͵���Ϣ:%s\r\n",Subg_UART3_Rx_Data);
        }
        
    }
    
}

/* �������Ʒ��� */
void Get_Val(int Auto_flag,ThresHod Auto_Threshod)
{
    if(Zibgbee_sendtime > 400 && Run_flag != ZIGBEECONFIG && Run_flag != SETZIGBEE &&  Run_flag != LCDSET)
    {
        if(Auto_flag == AUTOON)    //�Զ�ģʽ------����ʼ����ֵƴ������ͨ��ZigBee���͸��ӽڵ�ʵ���ӽڵ��Զ�ģʽ
        {
            sprintf(UART3_Tx_DMA_buffer,  "ON""-T:%d+%d""-H:%d+%d""-I:%d+%d""-S:%d+%d\r\n"                                                          
                                    ,Auto_Threshod.Temperature_Min
                                    ,Auto_Threshod.Temperature_Max
                                    ,Auto_Threshod.Humidity_Min
                                    ,Auto_Threshod.Humidity_Max
                                    ,Auto_Threshod.Intensity_Min
                                    ,Auto_Threshod.Intensity_Max
                                    ,Auto_Threshod.Smoke_Min
                                    ,Auto_Threshod.Smoke_Max);
            
        }
        else if(Auto_flag == AUTOOFF)//�ֶ�ģʽ------���豸״̬ͨ���ӽڵ㷢�͸��ӽڵ�ʵ���ֶ�����
        {
            memset(UART3_Tx_DMA_buffer,0,256);
            sprintf(UART3_Tx_DMA_buffer,  "OFF""-A:%d""-C:%d""-W:%d""-LED1:%d""-LED2:%d\r\n"                                                         
                                    ,Auto_Threshod.Air
                                    ,Auto_Threshod.Curtain
                                    ,Auto_Threshod.Window
                                    ,Auto_Threshod.LED1
                                    ,Auto_Threshod.LED2);
//            printf("�����������ֶ�������䣺\r\n");
//            scanf("%s",USART0_Tx_buffer);  //��������������-------OFF-A:1-C:1-W:1\r\n
            
            //sprintf(UART3_Tx_DMA_buffer,"%s\r\n",USART0_Tx_buffer);
            
        }
        UART3_DMA_Send(UART3_Tx_DMA_buffer);
        printf("�������͵Ŀ�����䣺%s\r\n",UART3_Tx_DMA_buffer);
        Zibgbee_sendtime = 0;
        
        
    }
}

char Lcd_reccompare[][16]={"AUTOON","AUTOOFF","AUTOOFFHANDON","HANDNUM","THRESHOLD_SET","SETZIGBEE","ZIGBEECONFIG","SET"};
int Run_flag; //ȫ�ֱ��� ������Ļʹ��

int UART_Lcd_Task(ThresHod *Auto_Threshod)
{
    char LCD_Rec[64] = {0};
    int find_i = 0, find_j = 0;
    
    if(Lcd_Read(15,LCD_Rec) == 1)    //��ʱ���մ��������͵���Ϣ
    {
        while(strstr(LCD_Rec,Lcd_reccompare[find_i++])==NULL)
		{	
			if(strstr(LCD_Rec,Lcd_reccompare[find_j--])!=NULL)
			{
				find_i = find_j+2;//��⵽��jΪ���һ�ε� ���Լ�һ �ٴμ�1 ����while
				break;
			}
			if (find_i == find_j)
			{
				return USELESS;
			}
			
		}
		--find_i;
		switch(find_i)
		{
			case AUTOON:                     //�Զ�ģʽ-----------
				printf("case:AUTOON\r\n");
			//    Zigbee_send(Lcd_rec);      //�ֶ�ģʽ �����ֶ�ģʽָ��
				Run_flag=AUTOON;
				return  AUTOON;				
			case AUTOOFF:
				printf("case:AUTOOFF\r\n");
			//    Zigbee_send(Lcd_rec);      //�ֶ�ģʽ �����ֶ�ģʽָ��
				Run_flag=AUTOOFF;
				return AUTOOFF;
			case AUTOOFFHANDON:
				printf("case:AUTOOFHANDON\r\n");
				
			//    Zigbee_send(Lcd_rec);      //�ֶ�ģʽ �����ֶ�ģʽָ��
				Run_flag=AUTOOFFHANDON;
				return AUTOOFFHANDON;
			case HANDNUM:
				printf("case:HANDNUM:%s\r\n",LCD_Rec);   
				sscanf(LCD_Rec,"HANDNUM-%d-%d-%d-%d-%d",
                                &Auto_Threshod->Air,
                                &Auto_Threshod->Curtain,
                                &Auto_Threshod->Window,
                                &Auto_Threshod->LED1,
                                &Auto_Threshod->LED2);                
			 //   Zigbee_send(Lcd_rec);      //�ֶ�ģʽ �����ֶ�ģʽָ��
				Run_flag=USELESS;
				return USELESS;
			case THRESHOLD_SET:
				printf("case:THRESHOLD_SET:%s\r\n",LCD_Rec);
				sscanf(LCD_Rec,"THRESHOLD_SET-%d+%d-%d+%d-%d+%d-%d+%d",
                                                     &Auto_Threshod->Temperature_Min,
                                                     &Auto_Threshod->Temperature_Max,
                                                     &Auto_Threshod->Humidity_Min,
                                                     &Auto_Threshod->Humidity_Max,
                                                     &Auto_Threshod->Intensity_Min,
                                                     &Auto_Threshod->Intensity_Max,
													 &Auto_Threshod->Smoke_Min,
													 &Auto_Threshod->Smoke_Max);
				Run_flag=USELESS;
				return USELESS;
			case SETZIGBEE:
				printf("case:SETZIGBEE\r\n");
				Run_flag=SETZIGBEE;
				return SETZIGBEE;
			case ZIGBEECONFIG:
				printf("case:ZIGBEECONFIG\r\n");
				Run_flag=ZIGBEECONFIG;
				return ZIGBEECONFIG;
			case LCDSET:
				printf("case:SET\r\n");
				Run_flag=LCDSET;
				return LCDSET;
			default:
				Run_flag=USELESS;
				return USELESS;
		}		
	}
     return USELESS;
}
//�ı�����ģʽ
int Change_mode(int Run_mode,int *Auto_flag)
{
    if(Run_mode == AUTOON)
	{	
		printf("Change_mode AUTOON\r\n");
        *Auto_flag = AUTOON;
	}
    else if(Run_mode == AUTOOFF)
    {
        printf("Change_mode AUTOOFF\r\n");
        *Auto_flag = AUTOOFF;	
    }
    return 0;
}

void ESP8266_Send_Recevice(void)
{
    int OStime=0;
    OStime++;
    delay_1ms(1);
    if(OStime%1000==0)
    {
        Send_ESP8266_String("AT\r\n");
    }
    if(ESP8266_Buff.UART6_Finish)
    {
        printf("%s\n",ESP8266_Buff.UART6_Buff);
        memset(ESP8266_Buff.UART6_Buff,0,sizeof(ESP8266_Buff.UART6_Buff));
        ESP8266_Buff.UART6_Index = 0;
        ESP8266_Buff.UART6_Finish = 0;
    }
    
}

void IrDA_Send_Recevice(ThresHod *Auto_Threshod,IrDA_Type *IrDA_Buff)
{
    if(IrDA_Buff->USART5_Finish)
    {
        printf("%c",IrDA_Buff->data);
        if(IrDA_Buff->data == 0x43)  //�л���ʪ��
        {
            switch(IrDA_Buff->Flag)//-----------ѡ����Ŀ��T(min/max)  H(min/max)  I(min/max)  S(min/max)��
            {
                case 0: *IrDA_Buff->Value_ThresHod = &Auto_Threshod->Temperature_Min;  break;   
                case 1: *IrDA_Buff->Value_ThresHod = &Auto_Threshod->Temperature_Max;  break;   
                case 2: *IrDA_Buff->Value_ThresHod = &Auto_Threshod->Humidity_Min;     break;   
                case 3: *IrDA_Buff->Value_ThresHod = &Auto_Threshod->Humidity_Max;     break;   
                case 4: *IrDA_Buff->Value_ThresHod = &Auto_Threshod->Intensity_Min;    break;   
                case 5: *IrDA_Buff->Value_ThresHod = &Auto_Threshod->Intensity_Max;    break;   
                case 6: *IrDA_Buff->Value_ThresHod = &Auto_Threshod->Smoke_Min;        break;   
                case 7: *IrDA_Buff->Value_ThresHod = &Auto_Threshod->Smoke_Max;        break;   
            }
            IrDA_Buff->Flag += 1;
        }
            
        switch(IrDA_Buff->data)
        {
            case 0x16:   break;    //0 -----------������ֵ
            case 0x0C:   break;    //1
            case 0x18:   break;    //2
            case 0x5E:   break;    //3
            case 0x08:   break;    //4
            case 0x1C:   break;    //5
            case 0x5A:   break;    //6
            case 0x42:   break;    //7
            case 0x52:   break;    //8
            case 0x4A:   break;    //9
            case 0x07:   break; **(IrDA_Buff->Value_ThresHod) --;  printf("%d\r\n",**IrDA_Buff->Value_ThresHod);//- -----------������ֵ�Ӽ�
            case 0x15:   break;    //+
            case 0x09:   break;    //ok ----------ȷ��
            case 0x45:   break;    //ch- ---------Air
            case 0x46:   break;    //ch  ---------Cur
            case 0x47:   break;    //ch+ ---------Win
        }
        IrDA_Buff->USART5_Finish = 0;
    }
    
}
    





